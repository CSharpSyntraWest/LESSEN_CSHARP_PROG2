﻿namespace Bieren.WPF.Services
{
    public interface IFileDialogService
    {
        string OpenFile(string filter);
    }
}