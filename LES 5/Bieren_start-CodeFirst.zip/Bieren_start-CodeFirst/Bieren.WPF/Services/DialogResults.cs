﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bieren.WPF.Services
{
    public enum DialogResults
    {
        Undefined,
        Yes,
        No,
        OK,
        Cancel
    }
}
