﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefeningenReeks2LINQ
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
