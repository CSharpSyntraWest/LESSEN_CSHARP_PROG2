﻿using System;

namespace OefeningenReeks2LINQ
{
    public class Order
    {
        #region Instance fields
        private int orderID;
        private string orderName;
        private DateTime orderDate;
        #endregion
        #region Ctor
        /// <summary>
        /// ctor
        /// </summary>
        public Order()
        {

        }
        #endregion
        #region Public Properties
        public int OrderID
        {
            get { return orderID; }
            set { orderID = value; }
        }
        public string OrderName
        {
            get { return orderName; }
            set { orderName = value; }
        }
        public DateTime OrderDate
        {
            get { return orderDate; }
            set { orderDate = value; }
        }

        public override string ToString()
        {
            return "OrderID :" + OrderID + "\r\n" +
                    "OrderName :" + OrderName + "\r\n" +
                    "OrderDate :" + OrderDate;
        }
        #endregion
    }
}