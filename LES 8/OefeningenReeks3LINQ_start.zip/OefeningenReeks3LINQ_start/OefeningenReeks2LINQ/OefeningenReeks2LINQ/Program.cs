﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OefeningenReeks2LINQ
{
    class Program
    {
        private static List<Item> _itemList;
        private static List<Order> _orderList;
        private static List<Customer> _customerList;
        static void Main(string[] args)
        {
            CreateLists();
            var itemOrders =
                      from i in _itemList
                      join o in _orderList on i.ItemID equals o.OrderID
                      select new { i.ItemName, o.OrderName };

            foreach (var r in itemOrders)
            {
                Console.WriteLine(r);
            }
            Console.ReadLine();
        }
        static void CreateLists()
        {
            _itemList = new List<Item>() {
                new Item{ ItemID= 1, ItemName = "Enclopedia", Category = "Knowledge", UnitPrice = 55.99M, UnitsInStock = 39},
                new Item { ItemID = 2, ItemName = "Trainers", Category="Sports", UnitPrice = 75.00M, UnitsInStock = 17 },
                new Item { ItemID = 3, ItemName = "Box of CDs", Category="Storage", UnitPrice = 4.99M, UnitsInStock = 13 },
                new Item { ItemID = 4, ItemName = "Tomatoe ketchup", Category="Food", UnitPrice = 0.56M, UnitsInStock = 53 },
                new Item { ItemID = 5, ItemName = "IPod", Category="Entertainment", UnitPrice = 220.99M, UnitsInStock = 0 },
                new Item { ItemID = 6, ItemName = "Rammstein CD", Category="Entertainment", UnitPrice = 7.99M, UnitsInStock = 120 },
                new Item { ItemID = 7, ItemName = "War of the worlds DVD", Category="Entertainment", UnitPrice = 6.99M, UnitsInStock = 15 },
                new Item { ItemID = 8, ItemName = "Cranberry Sauce", Category="Food", UnitPrice = 0.89M, UnitsInStock = 6 },
                new Item { ItemID = 9, ItemName = "Rice steamer", Category="Food", UnitPrice = 13.00M, UnitsInStock = 29 },
                new Item { ItemID = 10, ItemName = "Bunch of grapes", Category="Food", UnitPrice = 1.19M, UnitsInStock = 4 }};

            _orderList = new List<Order> {
                new Order { OrderID = 1, OrderName = "John Smith", OrderDate = DateTime.Now },
            new Order{ OrderID = 2, OrderName = "Professor X", OrderDate = DateTime.Now },
            new Order { OrderID = 3, OrderName = "Naomi Campbell", OrderDate = DateTime.Now },
            new Order{ OrderID = 4, OrderName = "The Hulk", OrderDate = DateTime.Now },
            new Order{ OrderID = 5, OrderName = "Malcolm X", OrderDate = DateTime.Now  }};

            _customerList = new List<Customer> {
        new Customer{ CustomerID = 1, CustomerName ="Jan", BirthDate = new DateTime(2000,1,1) },
        new Customer{ CustomerID = 2, CustomerName ="Piet", BirthDate = new DateTime(2001,2,14) },
        new Customer{ CustomerID = 3, CustomerName ="Joris", BirthDate =new DateTime(2003,3,31) },
        new Customer{ CustomerID = 4, CustomerName ="Korneel", BirthDate =new DateTime(2004,4,1) },
        new Customer{ CustomerID = 5, CustomerName ="Tom", BirthDate =new DateTime(2005,8,10)
        }};

        }
    }
}
