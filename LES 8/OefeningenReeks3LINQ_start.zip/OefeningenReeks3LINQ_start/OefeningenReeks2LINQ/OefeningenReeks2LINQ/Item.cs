﻿namespace OefeningenReeks2LINQ
{
    public class Item
    {
        #region Instance fields
        private int itemID;
        private string itemName;
        private string category;
        private decimal unitPrice;
        private int unitsInStock;
        #endregion
        #region Ctor
        /// <summary>
        /// ctor
        /// </summary>
        public Item()
        {

        }
        #endregion
        #region Public Properties
        public int ItemID
        {
            get { return itemID; }
            set { itemID = value; }
        }

        public string ItemName
        {
            get { return itemName; }
            set { itemName = value; }
        }


        public string Category
        {
            get { return category; }
            set { category = value; }
        }


        public decimal UnitPrice
        {
            get { return unitPrice; }
            set { unitPrice = value; }
        }


        public int UnitsInStock
        {
            get { return unitsInStock; }
            set { unitsInStock = value; }
        }

        public override string ToString()
        {
            return "ItemID :" + ItemID + "\r\n" +
                    "ItemName :" + ItemName + "\r\n" +
                    "Category :" + Category + "\r\n" +
                    "UnitPrice :" + UnitPrice + "\r\n" +
                    "UnitsInStock :" + UnitsInStock;
        }
        #endregion
    }
}