﻿namespace AbstractFactoryPattern.Abstractions
{
    public interface IDough: IGredient
    {
    }
}