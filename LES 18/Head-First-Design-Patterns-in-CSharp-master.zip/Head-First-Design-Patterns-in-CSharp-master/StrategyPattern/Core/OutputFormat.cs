namespace StrategyPattern.Core
{
    public enum OutputFormat
    {
        Markdown,
        Html
    }
}