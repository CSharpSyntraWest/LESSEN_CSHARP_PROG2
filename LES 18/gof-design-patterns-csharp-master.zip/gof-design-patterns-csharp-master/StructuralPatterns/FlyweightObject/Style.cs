﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlyweightObject
{
    class Style
    {
        public string _fontName;
        public int _fontSize;
        public string _fontColor;
    }
}
