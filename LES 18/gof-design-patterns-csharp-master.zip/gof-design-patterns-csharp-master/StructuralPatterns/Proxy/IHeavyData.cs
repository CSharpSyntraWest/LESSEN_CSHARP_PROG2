﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Proxy
{
    public interface IHeavyData
    {
        void LoadData();
        void DisplayData();
    }
}
