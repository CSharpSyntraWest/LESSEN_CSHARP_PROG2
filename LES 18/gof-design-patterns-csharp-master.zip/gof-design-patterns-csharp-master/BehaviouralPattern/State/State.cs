﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace State
{
    abstract class CaseState
    {        
        public abstract string WriteText(string text);
    }
}
