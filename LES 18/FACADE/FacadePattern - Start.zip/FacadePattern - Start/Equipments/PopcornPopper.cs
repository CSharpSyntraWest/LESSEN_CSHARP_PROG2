﻿using System;

namespace FacadePattern.Equipments
{
    public class PopcornPopper
    {
        public void On()
        {
            Console.WriteLine("Popcorn popper on");
        }

        public void Off()
        {
            Console.WriteLine("Popcorn popper off");
        }

        public void Pop()
        {
            Console.WriteLine("Popcorn popper popping popcorn");
        }
    }
}
