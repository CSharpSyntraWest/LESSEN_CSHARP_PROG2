﻿using System;
using System.Collections.Generic;

namespace Oef_SingletonPattern
{
    public sealed class Logger
    {
        //Vul hier de ontbrekende code aan om te zorgen dat er maar
        //één instantie van Logger kan worden aangemaakt

        private List<LogEvent> Events;

        private Logger()
        {
            this.Events = new List<LogEvent>();
        }

        public void SaveToLog(string message)
        {
            this.Events.Add(new LogEvent(message));
        }

        public void PrintLog()
        {
            foreach (var ev in this.Events)
            {
                Console.WriteLine("Time: {0}, Event: {1}", ev.EventDate.ToShortTimeString(), ev.Message);
            }
        }
    }
}
