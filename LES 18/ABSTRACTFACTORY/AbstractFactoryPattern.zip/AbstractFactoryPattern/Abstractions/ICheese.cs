﻿namespace AbstractFactoryPattern.Abstractions
{
    public interface ICheese: IGredient
    {
    }
}