﻿namespace AbstractFactoryPattern.Abstractions
{
    public interface IGredient
    {
        string Name { get; }
    }
}