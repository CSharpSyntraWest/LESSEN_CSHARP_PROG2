﻿namespace AbstractFactoryPattern.Abstractions
{
    public interface IClams: IGredient
    {
        
    }
}