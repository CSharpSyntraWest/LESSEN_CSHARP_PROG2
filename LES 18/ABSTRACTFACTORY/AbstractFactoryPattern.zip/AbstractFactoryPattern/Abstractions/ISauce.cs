﻿namespace AbstractFactoryPattern.Abstractions
{
    public interface ISauce: IGredient
    {
    }
}