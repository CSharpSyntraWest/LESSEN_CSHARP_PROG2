﻿namespace QueasoFramework.BusinessModels.Rules
{
    public class BrokenRule
    {
        #region Properties

        public string PropertyName { get; set; }
        public string FailedMessage { get; set; }

        //todo: maybe also keep which type of rule was broken? (businessrule, other derived rule class,...)
        //not really needed atm, as there is only one type of rule class (businessrule)

        #endregion

        #region Constructors

        public BrokenRule()
        {
            this.PropertyName = string.Empty;
            this.FailedMessage = string.Empty;
        }

        public BrokenRule(string failedMessage)
        {
            this.PropertyName = string.Empty;
            this.FailedMessage = failedMessage;
        }

        public BrokenRule(string failedMessage, string propertyName)
        {
            this.PropertyName = propertyName;
            this.FailedMessage = failedMessage;
        }
        #endregion
    }
}
