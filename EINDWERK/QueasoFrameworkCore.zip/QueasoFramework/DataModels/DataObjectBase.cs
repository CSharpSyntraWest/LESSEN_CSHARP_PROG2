﻿using System;
using System.ComponentModel.DataAnnotations;

namespace QueasoFramework.DataModels
{
    public abstract class DataObjectBase
    {
        #region Creation

        [Required]
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        #endregion

        #region Updated

        [Required]
        public string UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }

        #endregion

        #region Deleted

        public bool IsDeleted { get; set; } = false;
        public string DeletedBy { get; set; } = null;
        public DateTime? DeletedOn { get; set; } = null;

        #endregion
    }
}
