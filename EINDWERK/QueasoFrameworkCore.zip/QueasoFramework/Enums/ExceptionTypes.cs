﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueasoFramework.Enums
{
    public enum FrameworkExceptionType
    {
        Error = 1,
        Warning = 2,
        Info = 3,
        BusinessRuleViolation = 4
    }
}
